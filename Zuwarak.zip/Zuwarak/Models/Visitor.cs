﻿using System.ComponentModel.DataAnnotations;

namespace Zuwarak.Models
{
    public class Visitor
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string? FullName { get; set; } = string.Empty;
        [Required]
        public string? NationalId { get; set; } = string.Empty;
        [Required]
        public string? Phone { get; set; } = string.Empty;

        [Required]
        public string? Email { get; set; } = string.Empty;
        [Required]
        public string? VisitPurpose { get; set; }=string.Empty;

        [Required]
        public string? TargetPerson { get; set; } = string.Empty;



        public DateTime VisitDate { get; set; } = DateTime.Now;

        public string IDImagePath { get; set; }



        public bool IsArrived { get; set; } = false;
        public DateTime? ArrivalTime { get; set; }
        public bool IsCheckout { get; set; } = false;
        public DateTime? CheckoutTime { get; set; } 


    }
}
