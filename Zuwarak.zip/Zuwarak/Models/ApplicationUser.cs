﻿using Microsoft.AspNetCore.Identity;

namespace Zuwarak.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
